'''
Author:Rahul Bhattachan
KU ID: 3050953
Date:9/20/21
Lab 3
Purpose: The purpose of the helper_class is to phrase through
each line of the text file and call the designated 
functions from the web_history_class to replicate the
functionablity of a web browser.
'''

from web_history_class import webHistory

class Helper:

    # Initializes the class' attributes
    def __init__(self, file):
        self.run(file)

    # Contains the main chunk of code that is called by main()
    def run(self, file):
        try:
            inputFile = open(file)
            history = webHistory()
            for line in inputFile:
                if "HISTORY" in line: #Prints all history
                    history.history()
                elif "FORWARD" in line: #Changes newest page up one
                    history.forward()
                elif "BACK" in line: #Changes newest page down one
                    history.back()
                elif "NAVIGATE" in line: #Goes to newest page
                    history.navigate_to(line.split()[1])
        except FileNotFoundError:
            print("File not found")
