'''
Author:Rahul Bhattachan
KU ID: 3050953
Date:9/20/21
Lab 3
Purpose:Purpose of the node_class is to set the current 
node entry and set up a link to the next node.
'''

class Node:

    # Initializes the class' attributes
    def __init__(self, url):
        self.url = url
        self.next = None
