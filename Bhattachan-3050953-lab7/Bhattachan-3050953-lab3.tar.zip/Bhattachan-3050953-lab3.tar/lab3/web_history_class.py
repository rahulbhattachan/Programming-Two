'''
Author:Rahul Bhattachan
KU ID: 3050953
Date:9/20/21
Lab 3
Purpose:Purpose of the web_history_class is to replicate the functionability
of a web browser. It should be able to navigate to a url, go to the 
previous url, go to the next url, and be able to print out the history.
'''



from linked_list_class import LinkedList

class webHistory:

    # Initializes the class' attributes
    def __init__(self):
        self.linkedList = LinkedList()
        self.current = 0
    
    # Adds url as node in place of the page that's currently up
    def navigate_to(self, url):
        if self.current == self.linkedList.length():
            self.linkedList.insert(self.current, url)
            self.current += 1
        else:
            currentLength = self.linkedList.length()
            while self.current + 1 < currentLength:
                self.linkedList.remove(self.current)
                currentLength -= 1
            self.linkedList.set_entry(self.linkedList.length(), url)

    # Changes the current page by +1
    def forward(self):
        if self.current+1 <= self.linkedList.length():
            self.current += 1

    # Changes the current page by -1
    def back(self):
        if self.current-1 >= 1:
            self.current -= 1

    # Prints history
    def history(self):
        print("Oldest\n===========")
        index = 1
        while index <= self.linkedList._length:
            if (index == self.current):
                print(f"{self.linkedList.get_entry(index).url}  <==current")
            else:
                print(self.linkedList.get_entry(index).url)
            index += 1
        print("===========\nNewest\n")

