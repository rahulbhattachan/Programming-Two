'''
Author:Rahul Bhattachan
KU ID: 3050953
Date:9/20/21
Lab 3
Purpose: The purpose of the linked_list_class is to create a linked
list the is able to return it's current length, insert a new 
node at an index, remove a node at an index, get a node at an
index, set a node at an index, and clear itself.
'''

from node_class import Node

class LinkedList:

    # Initializes the class' attributes
    def __init__(self):
        self._front = None
        self._length = 0

    # Returns length of linked list
    def length(self):
        return self._length

    #Inserts new url with node into linked list
    def insert(self, index, entry):
        node = Node(entry)
        if self._front == None:
            self._front = node
        else:
            repeat = 1
            currentNode = self._front
            while repeat < index:
                if currentNode.next != None:
                    currentNode = currentNode.next
                    repeat += 1
            currentNode.next = node
        self._length+=1

    # Removes the current entry at an index
    def remove(self, index):
        repeat = 1
        currentNode = self._front
        while repeat < index:
            currentNode = currentNode.next
            repeat += 1
        currentNode.next = currentNode.next.next
        self._length -= 1

    # Returns the current entry at an index
    def get_entry(self, index):
        if index <= self._length and index >= 1:
            repeat = 1
            currentNode = self._front
            while repeat < index:
                currentNode = currentNode.next
                repeat += 1
            return currentNode
        else:
            raise RuntimeError("Index out of range.")

    # Sets the current entry at an index
    def set_entry(self, index, entry):
        repeat = 1
        currentNode = self._front
        while repeat < index:
            currentNode = currentNode.next
            repeat += 1
        currentNode.url = entry

    # Clears the linked list
    def clear(self):
        self._front = None
        self._length = 0
