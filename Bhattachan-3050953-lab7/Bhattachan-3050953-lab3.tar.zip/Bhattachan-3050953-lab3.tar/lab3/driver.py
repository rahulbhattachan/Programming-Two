'''
Author:Rahul Bhattachan
KU ID: 3050953
Date:9/20/21
Lab 3
Purpose: The purpose of the driver is to contain main() which
asks the user to input a file and then calls the executive
class if that file exsists.
'''

from helper_class import Helper

def main():
    print("")
    while True:
        try:
            dainput = input("File Name: ")
            print("")
            Helper(dainput)
            break
        except FileNotFoundError:
            print("File not found")

main()


